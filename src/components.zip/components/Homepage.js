import react from "react";
import Homepage from "./components/Homepage";

function Homepage() {
  return (
    <>
      <div>
        <h1>Welcome Dhruv to HomePage</h1>
      </div>
    </>
  );
}

export default Homepage;
