import React from "react";
import { useNavigate } from "react-router-dom";

const OnSubmit = () => {
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    const email = e.target.elements.value;
    const password = e.target.elements.value;
    // const login = login(email, password);
    let login = true;
    if (login) {
      navigate("/Homepage");
    } else {
      alert("Invalid user ID & Password");
    }
  };

  function onSubmit() {
    return (
      <>
        <div className="App">
          <nav className="navbar bg-primary">
            <div className="container-fluid">
              <h1 className="navbar-brand">Room-Expense Tracker</h1>
            </div>
          </nav>

          <div className="container">
            <div className="row d-flex justify-content-center">
              <div className="col-md-4">
                <form onSubmit={handleSubmit}>
                  <div className="form-group">
                    <h3>Login Your Account!</h3>
                    <label>Email address</label>
                    <input
                      type="email"
                      className="form-control"
                      id="EmailInput"
                      name="EmailInput"
                      aria-describedby="emailHelp"
                      placeholder="Enter email"
                      // onChange={(event) => setEmail(event.target.value)}
                    />
                    <small
                      id="emailHelp"
                      className="text-danger form-text"
                    ></small>
                  </div>
                  <div className="form-group">
                    <label>Password</label>
                    <input
                      type="password"
                      className="form-control"
                      id="exampleInputPassword1"
                      placeholder="Password"
                    />
                    <small
                      id="passworderror"
                      className="text-danger form-text"
                    ></small>
                  </div>
                  <div className="form-group form-check">
                    <input
                      type="checkbox"
                      className="form-check-input"
                      id="exampleCheck1"
                    />
                    <label className="form-check-label">Remember Me</label>
                  </div>
                  <button
                    type="submit"
                    className="btn btn-primary"
                    onSubmit={handleSubmit}
                  >
                    Submit
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </>
    );
  }
};
export default { OnSubmit };
